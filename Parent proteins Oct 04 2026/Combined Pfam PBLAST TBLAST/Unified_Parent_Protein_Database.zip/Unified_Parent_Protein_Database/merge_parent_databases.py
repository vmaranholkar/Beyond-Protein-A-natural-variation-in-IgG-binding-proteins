"""Merge exact protein sequences without losing source-specific evidence.

Python 3.9+, standard library only. See README.md and the supplied notebook.
Inputs are a processed NCBI extraction ZIP and one or more protein FASTAs.
"""
import csv
import hashlib
import io
import json
import re
import shutil
import sqlite3
import sys
import tempfile
import zipfile
from collections import Counter, defaultdict
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

VERSION = "1.0.0"
ALPHABET = set("ACDEFGHIKLMNPQRSTVWYUBZOJX*")
AMBIGUOUS = set("XBZJ")


class InputError(ValueError):
    pass


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def sequence_hash(sequence):
    return sha256(sequence.encode("ascii"))


def normalize(sequence):
    sequence = "".join(sequence.split()).upper()
    terminal_stop_removed = sequence.endswith("*")
    if terminal_stop_removed:
        sequence = sequence[:-1]
    if not sequence or set(sequence) - ALPHABET:
        raise InputError("Empty protein or invalid amino-acid characters: %r" % sequence[:80])
    return sequence, terminal_stop_removed


def fasta(text):
    """Yield every source record, including duplicated headers or sequences."""
    header, chunks = None, []
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        if line.startswith(">"):
            if header is not None:
                sequence, removed = normalize("".join(chunks))
                yield header, sequence, removed
            header, chunks = line[1:].strip(), []
            if not header:
                raise InputError("Empty FASTA header at line %s" % number)
        elif header is None:
            raise InputError("Sequence before a FASTA header at line %s" % number)
        else:
            chunks.append(line)
    if header is not None:
        sequence, removed = normalize("".join(chunks))
        yield header, sequence, removed


def read_fasta(path):
    return list(fasta(Path(path).read_text(encoding="utf-8-sig")))


def j(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def truth(value):
    if str(value).lower() not in ("true", "false", "1", "0"):
        raise InputError("Unrecognized Boolean value: %r" % value)
    return str(value).lower() in ("true", "1")


def archive_text(archive, basename):
    names = [n for n in archive.namelist() if Path(n).name == basename and not n.endswith("/")]
    if len(names) != 1:
        raise InputError("Expected exactly one %s in the extraction ZIP" % basename)
    return archive.read(names[0]).decode("utf-8-sig")


def archive_table(archive, basename, required):
    reader = csv.DictReader(io.StringIO(archive_text(archive, basename)), delimiter="\t")
    if set(required) - set(reader.fieldnames or []):
        raise InputError("Missing columns in %s: %s" % (basename, sorted(set(required) - set(reader.fieldnames or []))))
    rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise InputError("Malformed TSV rows in %s" % basename)
    return rows


def parse_header(header):
    """Parse supplied NCBI/Pfam/UniProt styles; retain the original header."""
    fields = dict(accession_version=header.split()[0], product="", organism="", taxonomy_id="",
                  review_status="", genomic_accession="", completeness="unknown",
                  completeness_evidence="", evidence_basis="FASTA_header", raw_header=header)
    complete = bool(re.search(r"\bcomplete CDS\b", header, re.I))
    partial = bool(re.search(r"\bpartial CDS\b|\bfragment\b", header, re.I))
    if complete and partial:
        fields["completeness"] = "conflicting_header_claims"
    elif complete:
        fields["completeness"] = "header_complete_CDS"
    elif partial:
        fields["completeness"] = "header_partial"
    if complete or partial:
        fields["completeness_evidence"] = "Literal text in FASTA header; underlying record not supplied here"
    organism = re.search(r"\[([^\[\]]+)\]", header)
    if organism:
        fields["organism"] = organism.group(1)
    genome = re.search(r"\bCDS from\s+(\S+)", header, re.I)
    if genome:
        fields["genomic_accession"] = genome.group(1)
    parts = header.split("|")
    if len(parts) >= 4 and parts[1] in ("reviewed", "unreviewed"):
        fields.update(accession_version=parts[0], review_status=parts[1], product=parts[2])
        tax = re.search(r"taxID:(\d+)", header)
        fields["taxonomy_id"] = tax.group(1) if tax else ""
    elif header.startswith(("sp|", "tr|")) and len(parts) >= 3:
        fields["accession_version"] = parts[1]
        fields["review_status"] = "reviewed" if parts[0] == "sp" else "unreviewed"
        tail = header.split(" ", 1)[1] if " " in header else ""
        fields["product"] = tail.split(" OS=", 1)[0]
        org = re.search(r" OS=(.*?)(?= OX=| GN=| PE=| SV=|$)", header)
        tax = re.search(r" OX=(\d+)", header)
        fields["organism"] = org.group(1) if org else ""
        fields["taxonomy_id"] = tax.group(1) if tax else ""
    else:
        tail = header.split(" ", 1)[1] if " " in header else ""
        fields["product"] = re.split(r"\s*\[|\s+(?:complete|partial) CDS", tail)[0].strip()
    return fields


def completeness_summary(observations, prior_full):
    values = {r["completeness"] for r in observations}
    record_full = "explicit_full_length" in values
    header_full = "header_complete_CDS" in values
    partial = bool(values & {"partial", "header_partial"})
    conflict = any("conflict" in v for v in values) or (partial and (record_full or header_full))
    if conflict:
        status = "mixed_or_conflicting_completeness_evidence"
    elif prior_full:
        status = "in_original_NCBI_annotated_full_length_subset"
    elif record_full:
        status = "record_full_length_claim_but_not_in_original_full_length_subset"
    elif header_full:
        status = "complete_CDS_header_claim_only"
    elif partial:
        status = "partial_evidence_only"
    else:
        status = "unknown"
    return dict(completeness_summary=status, has_record_full_length_claim=record_full,
                has_header_complete_CDS_claim=header_full, has_partial_evidence=partial,
                completeness_conflict=conflict)


def occurrences(sequence, query):
    start = sequence.find(query)
    while start != -1:
        yield start + 1, start + len(query)
        start = sequence.find(query, start + 1)


def write_tsv(path, rows, columns):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=columns, delimiter="\t", extrasaction="raise")
    writer.writeheader()
    writer.writerows(rows)
    Path(path).write_bytes(stream.getvalue().encode("utf-8"))


def write_fasta(path, proteins):
    with Path(path).open("w", encoding="utf-8") as stream:
        for p in proteins:
            stream.write(">%s length=%s sha256=%s\n" % (p["protein_id"], p["length_aa"], p["sequence_sha256"]))
            seq = p["sequence"]
            for i in range(0, len(seq), 80):
                stream.write(seq[i:i + 80] + "\n")


def build_database(ncbi_zip, fasta_sources, output_dir, binder_fasta=None,
                   candidate_prefix="IgG_binder_"):
    """Build a fresh database; existing nonempty output folders are refused.

    fasta_sources: list of dictionaries with source_id, path, search_method,
    and baseline (True for earlier sources used for the novelty comparison).
    The NCBI source is always part of the baseline. FASTA headers are evidence
    claims only; they never create GenBank-backed completeness annotations.
    """
    out = Path(output_dir).expanduser().resolve()
    if out.exists() and any(out.iterdir()):
        raise InputError("Output folder must be absent or empty: %s" % out)
    ncbi_zip = Path(ncbi_zip).expanduser().resolve()
    source_ids = ["ncbi_genbank"] + [s["source_id"] for s in fasta_sources]
    if len(source_ids) != len(set(source_ids)) or "binder_queries" in source_ids:
        raise InputError("Source IDs must be unique; binder_queries is reserved")
    if any(not re.fullmatch(r"[A-Za-z0-9_-]+", s) for s in source_ids):
        raise InputError("Use only letters, numbers, underscores and hyphens in source IDs")
    proteins, observations, features, links, originals, sources = {}, [], [], [], [], []
    source_sets = {}
    sequence_ids = {}

    def add_sequence(seq):
        digest = sequence_hash(seq)
        pid = "UP_" + digest[:24]
        if pid in proteins and proteins[pid]["sequence"] != seq:
            raise InputError("Sequence-hash ID collision")
        if pid not in proteins:
            proteins[pid] = dict(protein_id=pid, sequence_sha256=digest, length_aa=len(seq), sequence=seq,
                                 in_original_NCBI_full_length_subset=False)
        sequence_ids[seq] = pid
        return pid

    def add_source(sid, path, kind, method, baseline):
        path = Path(path).expanduser().resolve()
        if not path.is_file():
            raise InputError("Input file not found: %s" % path)
        sources.append(dict(source_id=sid, source_filename=path.name, source_kind=kind,
                            file_sha256=sha256(path.read_bytes()), file_bytes=path.stat().st_size,
                            search_method=method, baseline=baseline,
                            archived_path="inputs/%s%s" % (sid, path.suffix)))
        return path

    add_source("ncbi_genbank", ncbi_zip, "processed_GenBank_extraction_ZIP",
               "Earlier NCBI protein BLAST downloads; extraction parameters retained in original ZIP", True)
    with zipfile.ZipFile(ncbi_zip) as archive:
        extraction = json.loads(archive_text(archive, "summary.json"))
        if extraction.get("status") != "COMPLETED" or int(extraction.get("counts", {}).get("errors", 0)):
            raise InputError("NCBI extraction did not complete without errors")
        unique = archive_table(archive, "unique_proteins.tsv", ["protein_id", "sequence_sha256", "length_aa", "in_annotated_full_length_fasta"])
        by_old_id = {r["protein_id"]: r for r in unique}
        if len(by_old_id) != len(unique):
            raise InputError("Duplicate IDs in NCBI unique_proteins.tsv")
        old_to_new = {}
        for header, seq, _ in fasta(archive_text(archive, "unique_proteins.fasta")):
            old = header.split()[0]
            if old in old_to_new or old not in by_old_id:
                raise InputError("Duplicate or missing NCBI FASTA ID: %s" % old)
            row = by_old_id[old]
            if sequence_hash(seq) != row["sequence_sha256"] or len(seq) != int(row["length_aa"]):
                raise InputError("NCBI sequence hash/length mismatch: %s" % old)
            pid = add_sequence(seq)
            if pid in old_to_new.values():
                raise InputError("NCBI unique FASTA contains duplicate sequences")
            old_to_new[old] = pid
            originals.append(dict(source_id="ncbi_genbank", original_protein_id=old, protein_id=pid,
                                  original_metadata_json=j(row)))
        if set(old_to_new) != set(by_old_id):
            raise InputError("NCBI FASTA and metadata have different IDs")
        full_ids = set()
        for header, seq, _ in fasta(archive_text(archive, "annotated_full_length_proteins.fasta")):
            old = header.split()[0]
            if old not in old_to_new or seq != proteins[old_to_new[old]]["sequence"] or old in full_ids:
                raise InputError("NCBI full-length FASTA disagrees with main FASTA")
            if set(seq) & (AMBIGUOUS | {"*"}):
                raise InputError("Ambiguous/internal-stop sequence in NCBI full-length subset")
            full_ids.add(old)
            proteins[old_to_new[old]]["in_original_NCBI_full_length_subset"] = True
        for old, row in by_old_id.items():
            if truth(row["in_annotated_full_length_fasta"]) != (old in full_ids):
                raise InputError("NCBI full-length flag disagrees with whitelist")
        source_sets["ncbi_genbank"] = set(old_to_new.values())
        rows = archive_table(archive, "protein_records.tsv", ["occurrence_id", "protein_id", "source_record_sha256", "protein_accession_version", "completeness"])
        raw_to_ids = defaultdict(set)
        seen = set()
        for row in rows:
            old = row["protein_id"]
            if old not in old_to_new or row["occurrence_id"] in seen:
                raise InputError("NCBI occurrence has invalid protein or duplicate occurrence ID")
            seen.add(row["occurrence_id"])
            pid = old_to_new[old]
            if int(row["protein_length_aa"]) != proteins[pid]["length_aa"]:
                raise InputError("Occurrence length disagrees with sequence")
            raw_to_ids[row["source_record_sha256"]].add(pid)
            observations.append(dict(observation_id="ncbi_genbank:" + row["occurrence_id"], protein_id=pid,
                source_id="ncbi_genbank", source_record_sha256=row["source_record_sha256"],
                source_entry_id=row["source_entry_id"], source_file=row["source_file"],
                accession_version=row["protein_accession_version"], product=row["product"] or row["definition"],
                organism=row["organism"], taxonomy_id=row["taxonomy_id"], strain=row["strain"], isolate=row["isolate"],
                gene=row["gene"], locus_tag=row["locus_tag"], genomic_accession="", coded_by=row["coded_by"],
                completeness=row["completeness"], completeness_evidence=row["completeness_evidence"],
                evidence_basis="downloaded_GenBank_record", review_status="", raw_header="",
                terminal_stop_removed=truth(row["terminal_stop_removed"]), original_metadata_json=j(row)))
        if set().union(*raw_to_ids.values()) != source_sets["ncbi_genbank"]:
            raise InputError("Some NCBI proteins have no source occurrence")
        expected = extraction.get("counts", {})
        for key, actual in [("unique_proteins", len(unique)), ("protein_occurrences", len(rows)), ("annotated_full_length_unique_proteins", len(full_ids))]:
            if key in expected and int(expected[key]) != actual:
                raise InputError("NCBI extraction count mismatch: %s" % key)
        original_features = archive_table(archive, "features.tsv", ["source_record_sha256", "feature_type", "coordinate_unit", "start_1based", "end_inclusive"])
        for i, row in enumerate(original_features, 1):
            fid = "ncbi_genbank:F%08d" % i
            related = raw_to_ids.get(row["source_record_sha256"], set())
            if not related:
                raise InputError("Feature has no corresponding source record")
            features.append(dict(feature_id=fid, source_id="ncbi_genbank", **row))
            if row["coordinate_unit"] == "aa":
                if len(related) != 1:
                    raise InputError("Amino-acid feature has ambiguous sequence association")
                pid = next(iter(related))
                start, end = row["start_1based"], row["end_inclusive"]
                valid = bool(start and end)
                if valid and not 1 <= int(start) <= int(end) <= proteins[pid]["length_aa"]:
                    raise InputError("Amino-acid feature outside sequence bounds")
                links.append(dict(feature_id=fid, protein_id=pid, coordinate_basis="source_record_amino_acids",
                                  coordinate_bounds_validated=valid))

    input_paths = {"ncbi_genbank": ncbi_zip}
    for config in fasta_sources:
        sid = config["source_id"]
        path = add_source(sid, config["path"], "protein_FASTA", config.get("search_method", "Not supplied"), bool(config.get("baseline", False)))
        input_paths[sid] = path
        source_sets[sid] = set()
        entries = read_fasta(path)
        if not entries:
            raise InputError("Empty FASTA: %s" % path)
        for i, (header, seq, removed) in enumerate(entries, 1):
            pid = add_sequence(seq)
            source_sets[sid].add(pid)
            fields = parse_header(header)
            observations.append(dict(observation_id="%s:F%08d" % (sid, i), protein_id=pid, source_id=sid,
                source_record_sha256="", source_entry_id=header.split()[0], source_file=path.name,
                strain="", isolate="", gene="", locus_tag="", coded_by="", terminal_stop_removed=removed,
                original_metadata_json=j(dict(fasta_record_number=i, original_header=header)), **fields))

    grouped = defaultdict(list)
    accession_ids = defaultdict(set)
    for obs in observations:
        grouped[obs["protein_id"]].append(obs)
        if obs["accession_version"]:
            accession_ids[obs["accession_version"]].add(obs["protein_id"])
    conflicts = [dict(accession_version=a, protein_ids_json=j(sorted(ids)), distinct_sequence_count=len(ids))
                 for a, ids in sorted(accession_ids.items()) if len(ids) > 1]
    conflict_accessions = {r["accession_version"] for r in conflicts}
    baselines = {s["source_id"] for s in sources if s["baseline"]}
    baseline_ids = set().union(*(source_sets[s] for s in baselines))
    feature_counts = Counter(r["protein_id"] for r in links)
    for pid, p in proteins.items():
        obs = grouped[pid]
        p.update(completeness_summary(obs, p["in_original_NCBI_full_length_subset"]))
        all_accessions = sorted({r["accession_version"] for r in obs if r["accession_version"]})
        source_list = sorted({r["source_id"] for r in obs})
        ambiguous = sorted(set(p["sequence"]) & AMBIGUOUS)
        internal_stop = "*" in p["sequence"]
        p.update(source_ids_json=j(source_list), source_count=len(source_list), source_occurrence_count=len(obs),
            accession_versions_json=j(all_accessions), accession_count=len(all_accessions),
            organisms_json=j(sorted({r["organism"] for r in obs if r["organism"]})),
            taxonomy_ids_json=j(sorted({r["taxonomy_id"] for r in obs if r["taxonomy_id"]})),
            products_json=j(sorted({r["product"] for r in obs if r["product"]})),
            genomic_accessions_from_headers_json=j(sorted({r["genomic_accession"] for r in obs if r["genomic_accession"]})),
            ambiguous_residue_types="".join(ambiguous), has_internal_stop=internal_stop,
            has_accession_sequence_conflict=bool(set(all_accessions) & conflict_accessions),
            new_relative_to_baseline=pid not in baseline_ids,
            downloaded_aa_feature_count=feature_counts[pid],
            candidate_binder_count=0, candidate_match_occurrence_count=0)
        p["eligible_record_annotated_full_length"] = bool(p["in_original_NCBI_full_length_subset"] and not p["completeness_conflict"] and not ambiguous and not internal_stop)

    binder_rows, binder_matches = [], []
    if binder_fasta is not None:
        path = add_source("binder_queries", binder_fasta, "query_FASTA", "Shortlisted candidate and reference domain sequences", False)
        input_paths["binder_queries"] = path
        queries = read_fasta(path)
        query_ids = [h.split()[0] for h, _, _ in queries]
        if len(query_ids) != len(set(query_ids)):
            raise InputError("Duplicate query IDs in binder FASTA")
        for header, seq, _ in queries:
            bid = header.split()[0]
            candidate = not candidate_prefix or bid.startswith(candidate_prefix)
            matches, old_matches, record_full, header_full, conflict_hits = set(), set(), set(), set(), set()
            uncertain = bool(set(seq) & (AMBIGUOUS | {"*"}))
            if not uncertain:
                for pid, p in sorted(proteins.items()):
                    found = list(occurrences(p["sequence"], seq))
                    if not found:
                        continue
                    matches.add(pid)
                    if pid in baseline_ids:
                        old_matches.add(pid)
                    if p["eligible_record_annotated_full_length"]:
                        record_full.add(pid)
                    elif p["has_header_complete_CDS_claim"] and not p["completeness_conflict"] and not p["ambiguous_residue_types"] and not p["has_internal_stop"]:
                        header_full.add(pid)
                    if p["completeness_conflict"]:
                        conflict_hits.add(pid)
                    if candidate:
                        p["candidate_binder_count"] += 1
                        p["candidate_match_occurrence_count"] += len(found)
                    for start, end in found:
                        binder_matches.append(dict(binder_id=bid, is_candidate=candidate, protein_id=pid,
                            start_1based=start, end_inclusive=end, query_length_aa=len(seq)))
            status = ("ambiguous_or_internal_stop_query_not_searched" if uncertain else
                      "exact_match_record_annotated_full_length" if record_full else
                      "exact_match_complete_CDS_header_claim_only" if header_full else
                      "exact_match_completeness_unresolved" if matches else "no_exact_match")
            binder_rows.append(dict(binder_id=bid, is_candidate=candidate, sequence=seq, original_header=header,
                status=status, exact_parent_count=len(matches), baseline_exact_parent_count=len(old_matches),
                record_annotated_full_length_parent_count=len(record_full), header_complete_only_parent_count=len(header_full),
                completeness_conflict_parent_count=len(conflict_hits), newly_mapped=bool(matches and not old_matches)))

    protein_rows = [proteins[k] for k in sorted(proteins)]
    record_relations = sorted({(r["source_id"], r["source_record_sha256"], r["protein_id"]) for r in observations if r["source_record_sha256"]})
    relations = [dict(source_id=s, source_record_sha256=h, protein_id=p) for s,h,p in record_relations]
    source_counts = Counter(r["source_id"] for r in observations)
    cumulative = set()
    for s in sources:
        ids = source_sets.get(s["source_id"], set())
        s.update(source_record_count=source_counts[s["source_id"]], unique_sequence_count=len(ids),
                 sequences_added_in_input_order=len(ids - cumulative))
        cumulative |= ids
        if s["source_id"] == "binder_queries":
            s.update(source_record_count=len(binder_rows),
                     unique_sequence_count=len({r["sequence"] for r in binder_rows}))
    regions = {r["feature_id"] for r in features if r["feature_type"] == "Region" and r["coordinate_unit"] == "aa"}
    proteins_with_regions = {r["protein_id"] for r in links if r["feature_id"] in regions}
    summary = dict(status="COMPLETED", tool_version=VERSION, created_utc=datetime.now(timezone.utc).isoformat(),
        python=sys.version.split()[0], source_summaries=sources, unique_sequences=len(protein_rows),
        parent_source_occurrences=len(observations), baseline_unique_sequences=len(baseline_ids),
        new_unique_sequences=len(proteins) - len(baseline_ids),
        completeness_counts=dict(Counter(p["completeness_summary"] for p in protein_rows)),
        original_NCBI_full_length_sequences=sum(p["in_original_NCBI_full_length_subset"] for p in protein_rows),
        eligible_record_annotated_full_length_sequences=sum(p["eligible_record_annotated_full_length"] for p in protein_rows),
        completeness_conflict_sequences=sum(p["completeness_conflict"] for p in protein_rows),
        ambiguous_sequences=sum(bool(p["ambiguous_residue_types"]) for p in protein_rows),
        internal_stop_sequences=sum(p["has_internal_stop"] for p in protein_rows),
        accession_sequence_conflicts=len(conflicts), original_features_retained=len(features),
        proteins_with_downloaded_aa_Regions=len(proteins_with_regions),
        new_sequences_without_downloaded_aa_Regions=len(set(proteins) - baseline_ids - proteins_with_regions),
        source_membership_counts=dict(Counter(" + ".join(json.loads(p["source_ids_json"])) for p in protein_rows)),
        candidate_query_count=sum(r["is_candidate"] for r in binder_rows),
        candidate_status_counts=dict(Counter(r["status"] for r in binder_rows if r["is_candidate"])),
        candidate_queries_with_exact_match=sum(bool(r["exact_parent_count"]) for r in binder_rows if r["is_candidate"]),
        newly_mapped_candidates=sum(r["newly_mapped"] for r in binder_rows if r["is_candidate"]),
        candidate_parent_sequences=sum(bool(p["candidate_binder_count"]) for p in protein_rows),
        new_sequences_without_candidate_exact_match=sum(not p["candidate_binder_count"] and p["new_relative_to_baseline"] for p in protein_rows) if binder_fasta else None,
        candidate_parent_pairs=sum(p["candidate_binder_count"] for p in protein_rows),
        candidate_exact_occurrences=sum(p["candidate_match_occurrence_count"] for p in protein_rows),
        validation=dict(sequence_hashes_and_lengths="passed", full_length_whitelist="passed",
                        source_record_joins="passed", amino_acid_feature_bounds="passed"),
        caveats=["Search methodology for the new FASTA was not supplied; its source label does not imply independent validation.",
                 "FASTA complete CDS labels are header claims; underlying GenBank records, genomic coordinates and domain annotations were not supplied for the new set.",
                 "All metadata remain source-specific. Whole-sequence identity does not establish a unique genome, strain or functional activity.",
                 "Partials, ambiguous sequences and nonmatching candidates are retained and flagged. Fragments are not merged into longer sequences.",
                 "Downloaded annotations are preserved; no new Pfam scan, signal peptide prediction, sequence alignment or database retrieval was run."])
    # All input validation and analysis finish before any outputs are written.
    out.mkdir(parents=True, exist_ok=True)
    (out / "inputs").mkdir()
    for s in sources:
        shutil.copyfile(input_paths[s["source_id"]], out / s["archived_path"])
    write_fasta(out / "master_parent_proteins.fasta", protein_rows)
    write_fasta(out / "record_annotated_full_length.fasta", [p for p in protein_rows if p["eligible_record_annotated_full_length"]])
    write_fasta(out / "new_unique_sequences.fasta", [p for p in protein_rows if p["new_relative_to_baseline"]])
    if binder_fasta:
        write_fasta(out / "parents_with_candidate_exact_matches.fasta", [p for p in protein_rows if p["candidate_binder_count"]])
    tables = [
        ("sources", sources, list(sources[0])),
        ("proteins", protein_rows, list(protein_rows[0])),
        ("source_occurrences", observations, list(observations[0])),
        ("original_NCBI_unique_metadata", originals, ["source_id", "original_protein_id", "protein_id", "original_metadata_json"]),
        ("downloaded_features", features, list(features[0]) if features else ["feature_id","source_id","source_record_sha256","feature_type","coordinate_unit"]),
        ("source_record_sequences", relations, ["source_id", "source_record_sha256", "protein_id"]),
        ("feature_sequence_links", links, ["feature_id", "protein_id", "coordinate_basis", "coordinate_bounds_validated"]),
        ("accession_sequence_conflicts", conflicts, ["accession_version", "protein_ids_json", "distinct_sequence_count"]),
        ("binder_queries", binder_rows, list(binder_rows[0]) if binder_rows else ["binder_id", "sequence", "is_candidate"]),
        ("binder_exact_matches", binder_matches, ["binder_id", "is_candidate", "protein_id", "start_1based", "end_inclusive", "query_length_aa"])]
    # Finalize SQLite outside the export folder before publishing its bytes.
    # This keeps live journal files out of folders watched by sync software.
    staging = tempfile.TemporaryDirectory(prefix="parent_database_")
    database = Path(staging.name) / "parent_proteins.sqlite"
    with closing(sqlite3.connect(str(database))) as conn, conn:
        conn.execute("PRAGMA foreign_keys=ON")
        for name, rows, columns in tables:
            clauses = []
            for col in columns:
                numeric = bool(rows) and all(isinstance(r[col], (int, bool)) for r in rows)
                clauses.append('"%s" %s' % (col, "INTEGER" if numeric else "TEXT"))
            keys = {"sources":"source_id", "proteins":"protein_id", "source_occurrences":"observation_id", "downloaded_features":"feature_id", "binder_queries":"binder_id"}
            if name in keys:
                clauses.append('PRIMARY KEY ("%s")' % keys[name])
            if name != "proteins" and "protein_id" in columns:
                clauses.append('FOREIGN KEY (protein_id) REFERENCES proteins(protein_id)')
            if name != "sources" and "source_id" in columns:
                clauses.append('FOREIGN KEY (source_id) REFERENCES sources(source_id)')
            if name != "downloaded_features" and "feature_id" in columns:
                clauses.append('FOREIGN KEY (feature_id) REFERENCES downloaded_features(feature_id)')
            if name != "binder_queries" and "binder_id" in columns:
                clauses.append('FOREIGN KEY (binder_id) REFERENCES binder_queries(binder_id)')
            conn.execute('CREATE TABLE "%s" (%s)' % (name, ",".join(clauses)))
            conn.executemany('INSERT INTO "%s" VALUES (%s)' % (name, ",".join("?" for c in columns)),
                             [[r[c] for c in columns] for r in rows])
            export_columns = [c for c in columns if name != "proteins" or c != "sequence"]
            export_rows = [{c:r[c] for c in export_columns} for r in rows]
            write_tsv(out / (name + ".tsv"), export_rows, export_columns)
        conn.execute("CREATE INDEX observations_by_protein ON source_occurrences(protein_id)")
        conn.execute("CREATE INDEX observations_by_accession ON source_occurrences(accession_version)")
        conn.execute("CREATE INDEX matches_by_protein ON binder_exact_matches(protein_id)")
        conn.execute("CREATE INDEX matches_by_query ON binder_exact_matches(binder_id)")
        conn.execute("CREATE UNIQUE INDEX sequence_hash_unique ON proteins(sequence_sha256)")
        if conn.execute("PRAGMA foreign_key_check").fetchall():
            raise RuntimeError("SQLite foreign key validation failed")
        if conn.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
            raise RuntimeError("SQLite integrity validation failed")
    with closing(sqlite3.connect(str(database))) as check:
        for name, rows, columns in tables:
            actual = check.execute('SELECT COUNT(*) FROM "%s"' % name).fetchone()[0]
            if actual != len(rows):
                raise RuntimeError("Reopened database row count mismatch: %s" % name)
    (out / "parent_proteins.sqlite").write_bytes(database.read_bytes())
    staging.cleanup()
    summary["validation"]["sqlite_integrity_and_foreign_keys"] = "passed"
    summary["validation"]["reopened_database_table_counts"] = "passed"
    (out / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    write_tsv(out / "output_checksums.tsv", [dict(file=str(p.relative_to(out)), bytes=p.stat().st_size,
              sha256=sha256(p.read_bytes())) for p in sorted(out.rglob("*")) if p.is_file()], ["file", "bytes", "sha256"])
    print("Completed: %s unique sequences; %s new; %s source occurrences." % (len(proteins), summary["new_unique_sequences"], len(observations)))
    if binder_fasta:
        print("Exact matches: %s candidate queries; %s newly mapped." % (summary["candidate_queries_with_exact_match"], summary["newly_mapped_candidates"]))
    print("Database folder:", out)
    return summary


if __name__ == "__main__":
    print("Import build_database in the supplied notebook. See README.md for an example.")
