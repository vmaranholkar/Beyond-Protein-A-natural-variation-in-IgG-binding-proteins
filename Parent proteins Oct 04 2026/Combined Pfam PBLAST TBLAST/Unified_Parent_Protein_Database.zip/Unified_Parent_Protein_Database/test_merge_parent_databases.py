"""Regression tests for sequence identity and evidence preservation."""
import io
import json
import sqlite3
import tempfile
import unittest
import zipfile
from pathlib import Path

from merge_parent_databases import (InputError, build_database, completeness_summary,
                                    normalize, occurrences, parse_header, sequence_hash)


class MergeTests(unittest.TestCase):
    def test_only_whitespace_case_and_one_terminal_stop_are_normalized(self):
        self.assertEqual(normalize(" ma a\n*")[0], "MAA")
        self.assertEqual(normalize("MA*AA")[0], "MA*AA")
        self.assertEqual(normalize("MAX")[0], "MAX")
        with self.assertRaises(InputError):
            normalize("MA-AA")

    def test_header_claim_is_not_record_annotation(self):
        row = parse_header("ABC.1 protein [Test organism] complete CDS from CP001.1")
        self.assertEqual(row["completeness"], "header_complete_CDS")
        self.assertEqual(row["genomic_accession"], "CP001.1")
        self.assertEqual(row["organism"], "Test organism")
        summary = completeness_summary([row], False)
        self.assertFalse(summary["has_record_full_length_claim"])
        self.assertEqual(summary["completeness_summary"], "complete_CDS_header_claim_only")

    def test_conflicting_evidence_not_erased_by_full_claim(self):
        value = completeness_summary([{"completeness":"explicit_full_length"},
                                      {"completeness":"header_partial"}], True)
        self.assertTrue(value["completeness_conflict"])

    def test_exact_overlaps_and_ambiguity(self):
        self.assertEqual(list(occurrences("AAAAA", "AAA")), [(1,3),(2,4),(3,5)])
        self.assertEqual(list(occurrences("AAXAA", "AAA")), [])

    def test_pfam_and_uniprot_headers(self):
        pfam = parse_header("P123|reviewed|Protein A|taxID:1280")
        self.assertEqual((pfam["accession_version"], pfam["taxonomy_id"]), ("P123", "1280"))
        uni = parse_header("sp|P123|SPA_TEST Protein A OS=Test species OX=1280 GN=spa")
        self.assertEqual((uni["organism"], uni["review_status"]), ("Test species", "reviewed"))

    def fixture(self, root, wrong_hash=False):
        import csv
        def tsv(rows):
            s=io.StringIO(); w=csv.DictWriter(s, fieldnames=list(rows[0]), delimiter="\t")
            w.writeheader(); w.writerows(rows); return s.getvalue()
        seq="MAAAA"
        pid="UP_"+sequence_hash(seq)[:24]
        unique=dict(protein_id=pid,sequence_sha256="0"*64 if wrong_hash else sequence_hash(seq),
                    length_aa=5,in_annotated_full_length_fasta=True)
        fields="occurrence_id protein_id source_record_sha256 protein_accession_version completeness protein_length_aa source_entry_id source_file product definition organism taxonomy_id strain isolate gene locus_tag coded_by completeness_evidence terminal_stop_removed".split()
        obs=dict.fromkeys(fields, "")
        obs.update(occurrence_id="R1",protein_id=pid,source_record_sha256="record1",protein_accession_version="AAA.1",completeness="explicit_full_length",protein_length_aa=5,terminal_stop_removed=False)
        feature=dict(source_record_sha256="record1", feature_type="Region", coordinate_unit="aa",start_1based=2,end_inclusive=4,region_name="B",location_as_parsed="[1:4]",fuzzy_boundary=False)
        path=root/"parents.zip"
        with zipfile.ZipFile(path,"w") as z:
            z.writestr("summary.json",json.dumps(dict(status="COMPLETED",counts=dict(errors=0,unique_proteins=1,protein_occurrences=1,annotated_full_length_unique_proteins=1))))
            z.writestr("unique_proteins.tsv",tsv([unique]))
            z.writestr("unique_proteins.fasta",">%s\n%s\n"%(pid,seq))
            z.writestr("annotated_full_length_proteins.fasta",">%s\n%s\n"%(pid,seq))
            z.writestr("protein_records.tsv",tsv([obs]))
            z.writestr("features.tsv",tsv([feature]))
        return path,pid

    def test_merge_preserves_aliases_fragments_conflicts_and_features(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder); archive,pid=self.fixture(root)
            incoming=root/"more.fasta"
            incoming.write_text(">ALIAS.1 protein [Test species] complete CDS from CP1.1\nMAAAA\n"
                                ">AAA.1 fragment [Test species] partial CDS from CP2.1\nAAA\n")
            query=root/"queries.fasta"; query.write_text(">IgG_binder_1\nAAA\n>IgG_binder_2\nAXA\n")
            summary=build_database(archive,[dict(source_id="extra",path=incoming)],root/"out",query)
            self.assertEqual(summary["unique_sequences"],2)
            self.assertEqual(summary["accession_sequence_conflicts"],1)
            self.assertEqual(summary["original_features_retained"],1)
            self.assertEqual(summary["candidate_exact_occurrences"],3)
            with sqlite3.connect(str(root/"out/parent_proteins.sqlite")) as db:
                self.assertEqual(db.execute("select count(*) from source_occurrences where protein_id=?",(pid,)).fetchone()[0],2)
                self.assertEqual(db.execute("select protein_id from feature_sequence_links").fetchone()[0],pid)
                self.assertEqual(db.execute("select status from binder_queries where binder_id='IgG_binder_2'").fetchone()[0],"ambiguous_or_internal_stop_query_not_searched")
                self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(),[])

    def test_hash_mismatch_is_rejected_before_output(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder); archive,_=self.fixture(root,wrong_hash=True)
            with self.assertRaisesRegex(InputError,"hash/length mismatch"):
                build_database(archive,[],root/"out")
            self.assertFalse((root/"out").exists())


if __name__ == "__main__":
    unittest.main()
