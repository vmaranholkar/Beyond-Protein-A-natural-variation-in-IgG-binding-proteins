# Unified parent-protein sequence database

This package combines the three supplied parent-protein sources, removes only
whole-sequence duplicates, and preserves every source observation. It also
updates exact mapping of the original 974 candidate binder domains and six
reference domains. The original inputs are included for reproducibility.

## Results for these inputs

| Parent source | Source records | Unique sequences in that source | Sequences added in this order |
| --- | ---: | ---: | ---: |
| Earlier NCBI GenBank extraction | 15,829 | 1,439 | 1,439 |
| Earlier Pfam PF02216 FASTA | 77 | 67 | 56 |
| New alternative-search FASTA | 298 | 275 | 175 |
| Combined | 16,204 observations | **1,670** | **1,670** |

There are 100 new-FASTA unique sequences already present in the earlier combined
database. Their new accessions, genomic-accession claims and header information
are added to existing sequence entries. The other 175 become new entries.
The 23 duplicate records within the new FASTA are also retained as source
observations. Repeated downloaded observations are provenance, not independent
biological validation.

**This is a database of candidate parent sequences, including partial records.**
The 1,670 sequences must not be described as 1,670 confirmed full-length parents
or 1,670 distinct genes. Whole-sequence identity can occur at several accessions,
organisms or genomic locations.

## Sequence identity and stable identifiers

1. Remove whitespace, uppercase amino-acid letters, and remove one terminal `*`.
2. Compare the entire resulting sequence; compute its SHA-256 hash.
3. Assign `UP_` plus the first 24 hash characters as a stable sequence ID, with a
   collision check. The complete hash is retained and unique in SQLite.
4. Store one sequence per ID but keep every source accession and observation.

Sequences differing by one amino acid remain separate. A fragment contained in
a longer sequence remains separate. No similarity clustering, trimming,
replacement of X, or removal of internal stop symbols is performed. X/B/Z/J and
internal stops are flagged. Illegal characters, gaps, and empty sequences cause
an explicit input error. The 1,439 earlier NCBI sequence IDs are preserved by
the same hash convention.

## Where the information is stored

| File | Purpose |
| --- | --- |
| `database/master_parent_proteins.fasta` | All 1,670 unique normalized sequences |
| `database/parent_proteins.sqlite` | Searchable database containing sequences and all tabular information below |
| `database/proteins.tsv` | One row per sequence: source membership, all accessions, organism/taxonomy labels, products, quality, completeness evidence and binder counts |
| `database/source_occurrences.tsv` | All 16,204 observations with source filename, accession, organism, gene/locus/strain where available, completeness evidence, original header, and original metadata JSON |
| `database/downloaded_features.tsv` | All 7,287 original features, retaining source-record hashes, coordinate units, raw locations, fuzzy boundaries and qualifiers |
| `database/source_record_sequences.tsv` | Links raw source records to their protein sequences |
| `database/feature_sequence_links.tsv` | Links downloaded amino-acid features to exact sequences; does not convert genomic features to protein coordinates |
| `database/original_NCBI_unique_metadata.tsv` | Original NCBI sequence metadata and ID crosswalk |
| `database/accession_sequence_conflicts.tsv` | Same accession assigned to different sequences; currently zero conflicts |
| `database/binder_queries.tsv` | All 980 query entries, mapping status, match counts and whether newly mapped |
| `database/binder_exact_matches.tsv` | Every candidate/reference occurrence in every matching parent, including overlaps and repeats |
| `database/new_unique_sequences.fasta` | The 175 additions relative to the earlier combined NCBI/Pfam set |
| `database/record_annotated_full_length.fasta` | 249 sequences supported by the original NCBI full-length subset, without new contradictory evidence |
| `database/parents_with_candidate_exact_matches.fasta` | 1,649 sequences containing at least one exact candidate domain |
| `database/sources.tsv` | Input filenames, hashes, source labels, methods supplied and membership counts |
| `database/summary.json` | Analysis counts, validation results and limitations |
| `database/output_checksums.tsv` | Hashes and byte counts for the generated database outputs and archived inputs |
| `database/inputs/` | Exact input copies; the NCBI ZIP retains original GenBank records, extraction tables and processing logs |

TSV files can be opened in Excel using a **tab delimiter**. Import accession,
hash and taxonomy columns as text. List-valued fields use JSON so punctuation
within a protein description does not create ambiguous delimiters. The FASTA
headers are deliberately short; the SQLite file and tables retain the metadata.

The downloaded features belong to their original record. A feature linked to an
identical amino-acid sequence is available at the sequence level, but it is not
relabeled as a direct annotation of a different accession. Keep source-record
hashes and source accessions when reporting feature provenance. Genomic/bp
features remain in their original coordinate system and are not plotted on the
protein sequence. Raw compound and fuzzy locations are retained without
collapsing their interpretation to an exact continuous region.

## Completeness is evidence, not a length cutoff

The new FASTA has 221 headers marked `complete CDS` and 77 marked `partial CDS`.
These are **record counts**, not unique sequence counts. The underlying new
GenBank records were not provided, so the claims are stored as header evidence.
They never silently become a GenBank-backed full-length annotation.

| Combined sequence-level classification | Sequences |
| --- | ---: |
| In original NCBI annotated full-length subset | 249 |
| Complete-CDS claim in FASTA headers only | 173 |
| Partial evidence only | 963 |
| Completeness unknown | 284 |
| NCBI full-length claim but excluded from original strict subset | 1 |

The last category is retained rather than forcing it into the strict subset.
Its source quality information is available in the original metadata. There
are 34 sequences containing ambiguous residues, zero internal-stop sequences,
and no detected complete-versus-partial evidence conflicts in this input set.
If future sources disagree, both claims remain and a conflict flag is set.
Missing annotations are not evidence that a feature is absent.

## Updated binder mapping

Mapping uses literal identity over the entire query, with no gaps. Coordinates
are **1-based, inclusive**. Every parent match, repeat and overlapping occurrence
is retained. Reference queries are mapped but excluded from candidate counts.
Queries containing X/B/Z/J or internal stops are not searched as wildcards.

| Mutually exclusive candidate category | Candidates |
| --- | ---: |
| Exact match to a parent in the record-annotated full-length subset | 531 |
| No match in that subset, but a match to a sequence with a complete-CDS header claim | 153 |
| Exact match, with whole-parent completeness unresolved | 101 |
| No exact match in the combined database | 153 |
| Ambiguous query; not searched | 36 |
| Total candidates | **974** |

Thus 785 candidates have an exact match somewhere in the master database,
compared with 672 before this addition: **113 newly mapped candidates**. The
record-annotated full-length count remains 531 mapped candidates; the new header
evidence is a separate tier. Of the 175 new sequences, 158 have an exact candidate
match and 17 do not. All 175 remain in the master database. Across the full
database there are 87,103 distinct candidate-parent pairs and 89,291 candidate
occurrences. An exact sequence match alone does not establish the original
genomic source or experimentally validate IgG binding.

## Run or update in Jupyter (Python 3.9.12 compatible)

Extract this package completely and open `Merge_Parent_Protein_Databases.ipynb`
from the extracted folder. Run its cells from top to bottom. No extra packages
or Python upgrade are required: the workflow uses the Python standard library.
The notebook writes a new timestamped results directory and leaves the supplied
database intact. It also includes examples for looking up an accession and a
binder. Keep the script and notebook together.

To add a future FASTA, append an item to `FASTA_SOURCES` in the notebook:

```python
{
    "source_id": "search_4",
    "path": TOOLKIT_DIR / "my_additional_parents.fasta",
    "search_method": "Describe the actual database, release, search and filters",
    "baseline": False,
}
```

Set the previous `alternative_search` entry to `baseline=True` if the next
comparison should measure new additions relative to today's complete database.
Each source ID must be unique. Header parsers cover the supplied NCBI/Pfam
styles and standard UniProt headers; unknown headers are preserved verbatim,
with unavailable fields blank. If a new source has a different metadata format,
extend the parser explicitly rather than guessing. To add another annotated
GenBank dataset, first combine/re-extract the raw records using the earlier
extraction workflow, or add an explicit annotated-source importer; adding its
FASTA alone cannot preserve feature tables.

The Python entry point is `build_database(...)` in `merge_parent_databases.py`.
The accompanying tests check identity normalization, metadata preservation,
fragments, accession conflicts, feature joins, exact overlaps and corrupted
sequence hashes. Run `python -m unittest -v test_merge_parent_databases.py`.

## Information still needed for publication-quality provenance

The supplied FASTA preserves new protein accessions, organism names, products,
complete/partial-CDS claims and claimed source genomic accessions. It does not
contain the new CDS start/end positions, strand, gene/locus details, translation
qualifiers, supporting domain coordinates or the original search alignments.
In particular, **all 175 new sequences lack downloaded amino-acid Region
annotations in the supplied inputs**.

For those entries, retain or obtain the source GenBank/GenPept records and the
original search outputs. Record the exact search method, database and release,
retrieval date, query IDs, search parameters and filters. Preserve query-to-hit
links and genomic coordinates if the methodology involved translated genomic
searches. The integration timestamp in `summary.json` is not a database retrieval
date. The new method was described only as an alternative search, so that
metadata is explicitly marked as not supplied here.

If consistent domain architectures are required across every new parent, run
the same domain-annotation method with a recorded database release and settings
on all relevant sequences, preserving predicted annotations separately from
downloaded annotations. Do not infer PF02216 from a product name alone.

This master database package has a different schema from the earlier processed
`upload_package.zip`. It is not a drop-in input to the old figure notebook.
That notebook needs an adapter to read the master tables and display the new
completeness tiers and missing annotation evidence correctly.

## Methods text to adapt for the manuscript

Protein sequences from the NCBI-derived GenBank extraction, the supplied Pfam
PF02216 set, and an additional search were integrated into a sequence-indexed
database. Sequences were converted to uppercase, whitespace was removed, and
one terminal stop symbol was removed when present. Deduplication required
identity across the entire normalized amino-acid sequence; fragments and
nonidentical variants were retained separately. Stable sequence identifiers
were derived from SHA-256 hashes. All source accessions, source observations,
available taxonomy and product labels, and downloaded feature annotations were
retained with their provenance. Completeness evidence from downloaded records
was distinguished from complete-CDS claims in FASTA headers. Candidate binder
domains were mapped by exact, contiguous full-query matching, retaining all
candidate parents and repeated occurrences. Ambiguous queries were reported
separately and were not searched using wildcard matching. This integration
yielded 1,670 unique sequences, including 175 additions, and exact matches for
785 of 974 candidate domains. The additional search methodology and database
versions must be specified separately.
